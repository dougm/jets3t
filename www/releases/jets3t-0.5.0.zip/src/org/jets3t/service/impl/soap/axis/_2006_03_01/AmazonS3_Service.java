/**
 * AmazonS3_Service.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package org.jets3t.service.impl.soap.axis._2006_03_01;

public interface AmazonS3_Service extends javax.xml.rpc.Service {
    public java.lang.String getAmazonS3Address();

    public org.jets3t.service.impl.soap.axis._2006_03_01.AmazonS3_PortType getAmazonS3() throws javax.xml.rpc.ServiceException;

    public org.jets3t.service.impl.soap.axis._2006_03_01.AmazonS3_PortType getAmazonS3(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
